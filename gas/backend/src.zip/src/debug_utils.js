// @ts-nocheck
/**
 * debug_utils.gs
 * 本番コードから切り出したデバッグ用関数群（固定IDは使わない）
 * - 破壊的操作なし（閲覧/生成のみ）
 * - fileId か Drive URL を毎回手入力/引数で渡す
 */

/********** 共通ユーティリティ（安全） **********/
function parseDriveFileId(input){
  var s = String(input || '').trim();
  if (/^[A-Za-z0-9_-]{20,}$/.test(s)) return s;
  var m = s.match(/\/file\/d\/([^/]+)/); if (m) return m[1];
  m = s.match(/[?&]id=([^&]+)/);         if (m) return m[1];
  return '';
}

function getFileSafe_(id){
  id = String(id || '').trim();
  var lastErr;
  for (var i=0;i<3;i++){
    try{
      return DriveApp.getFileById(id);
    } catch(e){
      lastErr = e;
      Utilities.sleep(500);
    }
  }
  throw lastErr;
}

/********** 1) 同一フォルダの生成物一覧を表示 **********/
function debug_listOutputs(fileIdOrUrl){
  var id = parseDriveFileId(fileIdOrUrl);
  if (!id){ Logger.log('bad fileId/url'); return; }

  var file   = getFileSafe_(id);
  var parent = file.getParents().hasNext() ? file.getParents().next() : null;
  if (!parent){ Logger.log('parent not found'); return; }

  var names = [];
  var it = parent.getFiles();
  while(it.hasNext()){
    var f = it.next();
    var nm = f.getName();
    // 代表ID由来の成果物 or OCR派生ファイルを拾う
    if (nm.indexOf(id) === 0 || /\.ocr\.(txt|json)$/i.test(nm)) names.push(nm);
  }
  Logger.log('files:\n' + names.join('\n'));
}

/** 入力プロンプト付き（固定ID廃止） */
function debug_listOutputs_prompt(){
  var s = Browser.inputBox('Driveの fileId または URL を入力');
  if (s === 'cancel') return;
  debug_listOutputs(s);
}

/********** 2) _model.json（抽出結果）を表示 **********/
function debug_readModelJson(fileIdOrUrl){
  var id = parseDriveFileId(fileIdOrUrl);
  if (!id){ Logger.log('bad fileId/url'); return; }

  var file   = getFileSafe_(id);
  var parent = file.getParents().hasNext() ? file.getParents().next() : null;
  if (!parent){ Logger.log('parent not found'); return; }

  var name = id + '_model.json';
  var it = parent.getFilesByName(name);
  if (it.hasNext()){
    var json = it.next().getBlob().getDataAsString('utf-8');
    Logger.log(json);
  } else {
    Logger.log(name + ' not found');
  }
}

function debug_readModelJson_prompt(){
  var s = Browser.inputBox('Driveの fileId または URL を入力');
  if (s === 'cancel') return;
  debug_readModelJson(s);
}

/********** 3) エラーファイル（_extract_error.txt）を表示 **********/
function debug_readExtractError(fileIdOrUrl){
  var id = parseDriveFileId(fileIdOrUrl);
  if (!id){ Logger.log('bad fileId/url'); return; }

  var file   = getFileSafe_(id);
  var parent = file.getParents().hasNext() ? file.getParents().next() : null;
  if (!parent){ Logger.log('parent not found'); return; }

  var it = parent.getFilesByName(id + '_extract_error.txt');
  Logger.log(it.hasNext() ? it.next().getBlob().getDataAsString('utf-8') : 'error file not found');
}

function debug_readExtractError_prompt(){
  var s = Browser.inputBox('Driveの fileId または URL を入力');
  if (s === 'cancel') return;
  debug_readExtractError(s);
}

/********** 4) 既存のOCRテキストを使って /api/extract を“だけ”叩く **********
 * 本体の ensurePublicImageUrl_ / postExtract_ を利用します。
 * 既に <fileId>_model.json がある場合はスキップします。
 **********************************************************************/
function debug_postOnly(fileIdOrUrl, lineId){
  var id = parseDriveFileId(fileIdOrUrl);
  if (!id){ Logger.log('bad fileId/url'); return; }

  // 本体側にあるはずの関数が無い場合はエラーにする
  if (typeof ensurePublicImageUrl_ !== 'function' || typeof postExtract_ !== 'function'){
    throw new Error('ensurePublicImageUrl_ / postExtract_ が本体に見つかりません。先に本体へ定義してください。');
  }

  var file   = getFileSafe_(id);
  var parent = file.getParents().hasNext() ? file.getParents().next() : null;
  if (!parent){ Logger.log('parent not found'); return; }

  // 既に結果があればスキップ
  if (parent.getFilesByName(id + '_model.json').hasNext()){
    Logger.log('already has _model.json, skip');
    return;
  }

  // OCRテキストがあれば使用（無ければ空でOK）
  var ocrText = '';
  var it = parent.getFilesByName(file.getName() + '.ocr.txt');
  if (it.hasNext()){
    ocrText = it.next().getBlob().getDataAsString('utf-8');
  }

  // 画像の公開URLを確保
  var imageUrl = ensurePublicImageUrl_(file);

  // 抽出APIを叩く（lineIdは任意）
  var out = postExtract_(id, imageUrl, ocrText, lineId || 'LINE_DEBUG');

  // 成果物を保存
  if (out && out.ok && out.data){
    parent.createFile(
      Utilities.newBlob(JSON.stringify(out.data, null, 2), 'application/json', id + '_model.json')
    );
    Logger.log('saved: ' + id + '_model.json');
  } else {
    parent.createFile(
      Utilities.newBlob(
        'status=' + (out && out.status) + '\n' + (out && out.error || '') + '\n\n' + (out && out.raw || ''),
        'text/plain',
        id + '_extract_error.txt'
      )
    );
    Logger.log('saved: ' + id + '_extract_error.txt');
  }
}

function debug_postOnly_prompt(){
  var f = Browser.inputBox('Driveの fileId または URL を入力');
  if (f === 'cancel') return;
  var l = Browser.inputBox('lineId（任意・空可）を入力');
  if (l === 'cancel') return;
  debug_postOnly(f, l || 'LINE_DEBUG');
}


/**
 * ステージング: /_staging/<YYYY-MM>/submission_<SID>/ 以下を
 * /<氏名__LINEID>/<日本語ドキュメント名>/<YYYY-MM>/ へ移送する
 */
function fix_moveSubmissionToUser(submissionId, lineId, displayName) {
  if (!submissionId || !lineId) throw new Error('submissionId と lineId は必須');

  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const sRoot = getOrCreateFolder(root, '_staging');

  // submission_<sid> を全期間から探す（同SIDは通常1箇所）
  const ymIter = sRoot.getFolders();
  let movedCount = 0;
  while (ymIter.hasNext()) {
    const ym = ymIter.next(); // 'yyyy-MM'
    const subIter = ym.getFoldersByName(`submission_${submissionId}`);
    if (!subIter.hasNext()) continue;

    const sub = subIter.next(); // submission_<sid>
    const typeFolders = sub.getFolders(); // 日本語書類名（給与明細 等）

    while (typeFolders.hasNext()) {
      const typeFolder = typeFolders.next();
      const typeName = typeFolder.getName(); // 例: '給与明細'

      // 提出月はステージング元の yyyy-MM を採用
      const dest = ensurePathJapanese_(lineId, displayName || '', typeName, ym.getName());

      // 中身を全部移動
      const it = typeFolder.getFiles();
      while (it.hasNext()) {
        const f = it.next();
        dest.addFile(f);
        typeFolder.removeFile(f);
        movedCount++;
      }
    }

    // 空になった submission_<sid> を削除
    const leftover = sub.getFiles().hasNext() || sub.getFolders().hasNext();
    if (!leftover) ym.removeFolder(sub);
  }

  Logger.log(`moved files: ${movedCount}`);
}

function fix_moveSubmissionToUser_example() {
  var submissionId = '47862386';
  var lineId = 'Uc13df94016ee50eb9dd5552bffbe6624';
  var displayName = ''; // 任意（空でも可。台帳補完があるなら空でOK）
  fix_moveSubmissionToUser(submissionId, lineId, displayName);
}
