
/**
 * bootstrap.js
 * BAS 初回ログイン処理（caseId 採番 & Drive フォルダ作成）
 * 
 * 仕様:
 * - Next.js から { lineId, displayName, ts, sig } を受信
 * - sig = HMAC_SHA256(lineId + '|' + ts, SECRET)
 * - contacts upsert, caseId 採番, cases 追記, フォルダ作成
 * - レスポンス: { ok:true, userKey, activeCaseId, folderId }
 */

/** ---------- 設定 ---------- **/
const PROP = PropertiesService.getScriptProperties();
const SPREADSHEET_ID = PROP.getProperty('BAS_MASTER_SPREADSHEET_ID'); // BAS_master
const DRIVE_ROOT_ID = PROP.getProperty('DRIVE_ROOT_FOLDER_ID');       // BAS_提出書類ルート
const SECRET = PROP.getProperty('BOOTSTRAP_SECRET') || '';
const LOG_SHEET_ID = PROP.getProperty('GAS_LOG_SHEET_ID') || '';      // 任意

/** ---------- ユーティリティ ---------- **/
function jsonResponse(obj, status) {
  const out = ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
  if (status && out.setStatusCode) out.setStatusCode(status);
  return out;
}

function appendLog_(arr) {
  if (!LOG_SHEET_ID) return;
  try {
    const ss = SpreadsheetApp.openById(LOG_SHEET_ID);
    const sh = ss.getSheetByName('logs') || ss.insertSheet('logs');
    sh.appendRow(arr);
  } catch (_) {}
}

function hmacBase64(secret, msg) {
  return Utilities.base64Encode(
    Utilities.computeHmacSha256Signature(
      Utilities.newBlob(msg).getBytes(),
      Utilities.newBlob(secret).getBytes()
    )
  );
}

function getSheet_(name) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet not found: ' + name);
  return sh;
}

function toIndexMap_(headers) {
  const m = {};
  headers.forEach((h, i) => (m[h] = i));
  return m;
}

/** ---------- contacts upsert ---------- **/
function upsertContact_(lineId, displayName) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sh = ss.getSheetByName('contacts') || ss.insertSheet('contacts');

  let headers = sh.getRange(1, 1, 1, sh.getLastColumn() || 1).getValues()[0];
  if (!headers || headers.join('') === '') {
    headers = ['lineId', 'displayName', 'userKey', 'rootFolderId', 'nextCaseSeq', 'activeCaseId'];
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }
  const idx = toIndexMap_(headers);

  const userKey = lineId.slice(0, 6).toLowerCase();
  const rowCount = sh.getLastRow() - 1;
  const rows = rowCount > 0 ? sh.getRange(2, 1, rowCount, headers.length).getValues() : [];
  let row = -1;
  for (let i = 0; i < rows.length; i++) {
    if (rows[i][idx['lineId']] === lineId) {
      row = 2 + i;
      break;
    }
  }

  if (row > 0) {
    sh.getRange(row, idx['displayName'] + 1).setValue(displayName);
    sh.getRange(row, idx['userKey'] + 1).setValue(userKey);
  } else {
    const values = new Array(headers.length).fill('');
    values[idx['lineId']] = lineId;
    values[idx['displayName']] = displayName;
    values[idx['userKey']] = userKey;
    values[idx['rootFolderId']] = DRIVE_ROOT_ID;
    values[idx['nextCaseSeq']] = 1;
    values[idx['activeCaseId']] = '';
    sh.appendRow(values);
    row = sh.getLastRow();
  }

  return { row, userKey };
}

/** ---------- caseId 採番 ---------- **/
function allocateCaseId_(lineId, userKey) {
  const sh = getSheet_('cases');
  let headers = sh.getRange(1, 1, 1, sh.getLastColumn() || 1).getValues()[0];
  if (!headers || headers.join('') === '') {
    headers = ['lineId', 'userKey', 'caseId', 'caseKey', 'displayName', 'folderId', 'createdAt', 'status', 'lastActivity'];
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
  }
  const idx = toIndexMap_(headers);

  const rowCount = sh.getLastRow() - 1;
  const rows = rowCount > 0 ? sh.getRange(2, 1, rowCount, headers.length).getValues() : [];
  let max = 0;
  for (let i = 0; i < rows.length; i++) {
    if (rows[i][idx['userKey']] === userKey) {
      const n = parseInt(rows[i][idx['caseId']], 10);
      if (Number.isFinite(n)) max = Math.max(max, n);
    }
  }
  const next = String(max + 1).padStart(4, '0');
  const caseKey = `${userKey}-${next}`;
  const now = new Date().toISOString();

  const values = new Array(headers.length).fill('');
  values[idx['lineId']] = lineId;
  values[idx['userKey']] = userKey;
  values[idx['caseId']] = next;
  values[idx['caseKey']] = caseKey;
  values[idx['displayName']] = ''; // 表示名は contacts に保持
  values[idx['folderId']] = '';
  values[idx['createdAt']] = now;
  values[idx['status']] = 'draft';
  values[idx['lastActivity']] = now;
  sh.appendRow(values);

  return { caseId: next, caseKey, row: sh.getLastRow(), idx };
}

/** ---------- フォルダ作成 ---------- **/
function ensureCaseFolder_(caseKey) {
  const root = DriveApp.getFolderById(DRIVE_ROOT_ID);
  const it = root.getFoldersByName(caseKey);
  if (it.hasNext()) return it.next().getId();
  return root.createFolder(caseKey).getId();
}

/** ---------- doPost ---------- **/
function doPost(e) {
  try {
    if (!SECRET) return jsonResponse({ ok: false, error: 'config_error' }, 500);
    const raw = e?.postData?.contents ?? '';
    const lineId = (JSON.parse(raw).lineId || '').toString();
    const displayName = JSON.parse(raw).displayName || '';
    const ts = Number(e?.parameter?.ts || 0);
    const sig = String(e?.parameter?.sig || '');

    // ts 妥当性
    const nowSec = Math.floor(Date.now() / 1000);
    if (!ts || Math.abs(nowSec - ts) > 300) {
      return jsonResponse({ ok: false, error: 'bad_ts' }, 401);
    }

    // 署名検証
    const base = lineId + '|' + ts;
    const comp = hmacBase64(SECRET, base);
    if (!sig || sig !== comp) {
      return jsonResponse({ ok: false, error: 'bad_sig' }, 401);
    }

    // contacts upsert
    const up = upsertContact_(lineId, displayName);

    // caseId 採番
    const c = allocateCaseId_(lineId, up.userKey);

    // フォルダ作成 & cases 更新
    const folderId = ensureCaseFolder_(c.caseKey);
    const shCases = getSheet_('cases');
    shCases.getRange(c.row, c.idx['folderId'] + 1).setValue(folderId);

    // contacts 更新
    const shContacts = getSheet_('contacts');
    shContacts.getRange(up.row, 6).setValue(c.caseId); // activeCaseId

    return jsonResponse({ ok: true, userKey: up.userKey, activeCaseId: c.caseId, folderId });
  } catch (err) {
    return jsonResponse({ ok: false, error: String(err) }, 500);
  }
}
