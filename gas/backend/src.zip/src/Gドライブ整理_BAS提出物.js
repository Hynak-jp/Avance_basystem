/********** 設定 **********/
const ROOT_FOLDER_ID = '15QnwkhoXUkh8gVg56R3cSX-fg--PqYdu'; // 親フォルダIDを入れる
const SHEET_ID = ''; // 既存の台帳シートを使うならIDを入れる。空なら後で自動生成可能
const LABEL_TO_PROCESS = 'FormAttach/ToProcess';
const LABEL_PROCESSED = 'FormAttach/Processed';
const ASIA_TOKYO = 'Asia/Tokyo';

// Script Properties 推奨（プロパティ未設定ならトンネル直URLを既定）
const PROPS = PropertiesService.getScriptProperties();
const BASE = (
  PROPS.getProperty('NEXT_BASE_URL') || 'https://depot-heath-television-ga.trycloudflare.com'
).replace(/\/+$/, '');
const NEXT_API_URL = `${BASE}/api/extract`;
const SECRET = PROPS.getProperty('SECRET') || 'FM-BAS';
const ENABLE_FORM_LOG_SHORTCUTS = false; // ← ショートカット不要なら false

/** 書類種別：フォルダは日本語(type)、ファイルは英数字コード(code) */
const DOC_MAP = [
  { labels: ['給与明細', '給料明細', '給料の明細', '給与'], type: '給与明細', code: 'PAY' },
  { labels: ['銀行通帳の写し', '銀行通帳', '通帳', 'bank'], type: '銀行通帳', code: 'BANK' },
  { labels: ['家計収支表', '家計簿', '収支表', 'budget'], type: '家計収支表', code: 'BUDG' },
];

/** 対象年月(YYYYMM)抽出 */
const PERIOD_PATS = [
  { pat: /(\d{4})[-./年](\d{1,2})(?:月)?/, to: (y, m) => `${y}${('0' + m).slice(-2)}` }, // 2025-08 / 2025年8月
  { pat: /(\d{2})[-./](\d{1,2})/, to: (y, m) => `20${y}${('0' + m).slice(-2)}` }, // 25-08
  { pat: /令和(\d+)年(\d{1,2})月/, to: (ry, m) => `${2018 + Number(ry)}${('0' + m).slice(-2)}` }, // 令和n年m月
];

// 既に名前付きフォルダがある場合の方針: 'first'（最初の名前を尊重）or 'latest'（常に最新に更新）
const RENAME_STRATEGY = 'latest';
const FOLDER_NAME_MAX = 80; // Drive の見やすさ用に適度に丸める

// 「書類提出」を1つのフォルダにまとめる
const DOCS_BUCKET_NAME = '書類提出';
const DOCS_FORM_KEYWORDS = ['書類提出']; // フォーム名にこの語が含まれたら集約
function isDocsSubmission(formName) {
  const s = String(formName || '');
  return DOCS_FORM_KEYWORDS.some((k) => s.includes(k));
}

// 原本（回答シート）をルートから探す
function findFormSheetInMyDriveRoot_(formName) {
  // ルート直下にあり、かつ Spreadsheet のものを名前一致で拾う
  // DriveApp は「場所での検索」が弱いので、名前一致で妥協（同名が複数あるケースは稀）
  const files = DriveApp.getFilesByName(formName);
  while (files.hasNext()) {
    const f = files.next();
    if (f.getMimeType() === MimeType.GOOGLE_SHEETS) {
      // ルート直下かどうかは判定が難しいので、まずは最初の一致を採用（必要があれば厳密化）
      return f;
    }
  }
  return null;
}

//ショートカット作成（可能なら）＋台帳 upsert
function upsertFormLogRegistry_(formName) {
  const ss = openOrCreateMaster_();
  const sh = ss.getSheetByName('form_logs');
  const data = sh.getDataRange().getValues();
  const now = Utilities.formatDate(new Date(), ASIA_TOKYO, 'yyyy-MM-dd HH:mm:ss');

  let row = -1;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(formName)) {
      row = i + 1;
      break;
    }
  }

  const src = findFormSheetInMyDriveRoot_(formName);
  if (!src) {
    if (row > 0) sh.getRange(row, 8).setValue(now); // last_seen
    return null;
  }
  const sheetId = src.getId();
  const sheetUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/edit`;

  let shortcutId = '',
    shortcutUrl = '',
    mirrored = 'no';
  if (ENABLE_FORM_LOG_SHORTCUTS) {
    try {
      if (Drive && Drive.Files) {
        const folder = ensureFormLogsFolder_(); // _form_logs を本当に使う時だけ作る
        const maybe = folder.getFilesByName(formName + '（原本へのショートカット）');
        if (maybe.hasNext()) {
          const sc = maybe.next();
          shortcutId = sc.getId();
          shortcutUrl = `https://drive.google.com/file/d/${shortcutId}/view`;
          mirrored = 'yes';
        } else {
          const resource = {
            title: formName + '（原本へのショートカット）',
            mimeType: 'application/vnd.google-apps.shortcut',
            parents: [{ id: folder.getId() }],
            shortcutDetails: { targetId: sheetId },
          };
          const sc = Drive.Files.insert(resource);
          shortcutId = sc.id;
          shortcutUrl = `https://drive.google.com/file/d/${shortcutId}/view`;
          mirrored = 'yes';
        }
      }
    } catch (_) {
      mirrored = 'no';
    }
  }

  if (row < 0) {
    sh.appendRow([
      formName,
      sheetId,
      sheetUrl,
      fmt(new Date(src.getDateCreated())),
      shortcutId,
      shortcutUrl,
      mirrored,
      now,
    ]);
  } else {
    if (!data[row - 1][1]) sh.getRange(row, 2).setValue(sheetId);
    if (!data[row - 1][2]) sh.getRange(row, 3).setValue(sheetUrl);
    sh.getRange(row, 5).setValue(shortcutId);
    sh.getRange(row, 6).setValue(shortcutUrl);
    sh.getRange(row, 7).setValue(mirrored);
    sh.getRange(row, 8).setValue(now);
  }
  return { sheetId, sheetUrl, shortcutId, shortcutUrl, mirrored };
}

// 件名パース（テンプレに合わせた正規表現）
const RX_SUBJECT_SECRET = /\[#FM-BAS\]/i;
const RX_SUBJECT_LINE = /(?:^|\s)line:([A-Za-z0-9_-]+)/i;
const RX_SUBJECT_SID = /(?:^|\s)sid:([A-Za-z0-9_-]+)/i;

// META/FIELDSブロック
const RX_META_BLOCK = /====\s*META START\s*====([\s\S]*?)====\s*META END\s*====/i;
const RX_FIELDS_BLOCK = /====\s*FIELDS START\s*====([\s\S]*?)====\s*FIELDS END\s*====/i;

// META内のkey:value行
const RX_META_KV = /^\s*([A-Za-z0-9_]+)\s*:\s*(.*?)\s*$/gm;
// FIELDSの行（例: 「【ラベル】 値」 を抽出）
const RX_FIELD_LINE = /^\s*【(.+?)】\s*(.*)$/gm;

// ==== OCR PoC 追加設定 ====
const OCR_TARGET_FORMS = []; // []テスト用に空です。運用時はフォーム名に['書類', '給与明細']などを含む場合だけOCR実行
const OCR_LANG_HINTS = ['ja', 'en']; // 日本語＋英語
const OCR_PROCESSED_PROP = 'ocr_processed'; // Driveファイルのプロパティ名

/** ===== JSON保存: submission_logsフォルダ廃止版 ===== */
/** METAブロック抽出（==== META START ==== ... ==== META END ====） */
function parseMetaBlock_(text) {
  if (!text) return {};
  const m = text.match(/====\s*META START\s*====([\s\S]*?)(?:====\s*META END\s*====|$)/i);
  if (!m) return {};
  const meta = {};
  for (const raw of m[1].split(/\r?\n/)) {
    const line = String(raw).trim();
    if (!line || line.startsWith('#')) continue;
    const p = line.indexOf(':');
    if (p < 0) continue;
    meta[line.slice(0, p).trim().toLowerCase()] = line.slice(p + 1).trim();
  }
  return meta;
}

/** 英数_ 正規化 */
function normalizeKey_(s) {
  s = String(s || '');
  s = s.replace(/[！-～]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0)); // 全角→半角
  s = s.replace(/[^\x20-\x7E]/g, ' ');
  s = s.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return s || 'unknown';
}

/** 件名タグ [BAS:xxx] を拾う（フォールバック） */
function resolveFormKeyFromSubject_(subject) {
  const m = String(subject || '').match(/\[BAS:([A-Za-z0-9_]+)\]/);
  return m ? m[1] : '';
}

/** 最終 form_key を決定：META > hidden field > 件名タグ > form_name 正規化 > unknown */
function resolveFormKeyFinal_(mailPlainBody, fields, subject) {
  const meta = parseMetaBlock_(mailPlainBody);
  let k = (meta.form_key || '').trim();
  if (!k) k = String(fields['form_key'] || fields['フォームキー'] || '').trim();
  if (!k) k = resolveFormKeyFromSubject_(subject);
  if (!k && meta.form_name) k = normalizeKey_(meta.form_name);
  return normalizeKey_(k || 'unknown');
}

/** ユーザーフォルダ直下に JSON 保存（submission_logs は使わない） */
function saveSubmissionJsonShallow_(
  userFolder,
  submissionId,
  mailPlainBody,
  fields,
  subject,
  lineId
) {
  const formKey = resolveFormKeyFinal_(mailPlainBody, fields, subject);
  const caseId = resolveCaseId_(mailPlainBody, subject, lineId);
  const name = `${formKey}__${submissionId}.json`;
  const payload = JSON.stringify(
    { submission_id: submissionId, meta: { form_key: formKey, case_id: caseId, subject }, fields },
    null,
    2
  );
  return userFolder.createFile(name, payload, MimeType.JSON);
}

/** ===== 添付ファイル保存: 月フォルダ廃止・ファイル名YYYYMM化 ===== */
/** カテゴリ別の保存先フォルダ名とTYPEコード */
const ATTACH_RULE = {
  PAY: { folder: '給与明細', exts: ['png', 'jpg', 'jpeg', 'pdf', 'heic', 'webp'] },
  BANK: { folder: '銀行通帳', exts: ['png', 'jpg', 'jpeg', 'pdf', 'heic', 'webp'] },
  BUDG: { folder: '家計収支表', exts: ['png', 'jpg', 'jpeg', 'pdf', 'heic', 'webp'] },
  TAX: { folder: '税金関連', exts: ['png', 'jpg', 'jpeg', 'pdf', 'heic', 'webp'] },
  ETC: { folder: 'その他', exts: ['png', 'jpg', 'jpeg', 'pdf', 'heic', 'webp'] },
};

/** 元ファイル名や推定から TYPE を決める（必要に応じて拡張） */
function detectTypeCode_(name, hintedType) {
  const n = String(name || '').toLowerCase();
  const h = String(hintedType || '').toUpperCase();
  if (h && ATTACH_RULE[h]) return h;
  if (/pay|給与|給料|salary/.test(n)) return 'PAY';
  if (/bank|通帳|口座|statement/.test(n)) return 'BANK';
  if (/budg|家計|収支|budget/.test(n)) return 'BUDG';
  if (/tax|住民税|市県民税|国保|年金|保険料/.test(n)) return 'TAX';
  return 'ETC';
}

/** yyyymm を決める（メール受信日時 or 画像EXIFから決めてもOK。ここは受信日基準） */
function yyyymmFromDate_(d) {
  const pad = (x) => String(x).padStart(2, '0');
  return d.getFullYear() + pad(d.getMonth() + 1);
}

/** 同名があれば _2, _3... を付与して衝突回避 */
function uniqueNameInFolder_(folder, baseName, ext) {
  let name = `${baseName}.${ext}`;
  let i = 2;
  while (folder.getFilesByName(name).hasNext()) {
    name = `${baseName}_${i}.${ext}`;
    i++;
  }
  return name;
}

/**
 * 添付ファイルを「カテゴリ/ YYYYMM_TYPE[_連番].ext」で保存（浅い構造）
 * @param {Folder} userFolder - ユーザーのルートフォルダ（または staging のベース）
 * @param {Blob} blob - Gmailから取得した添付Blob
 * @param {Object} opts - { hintedType?: 'PAY'|'BANK'|'BUDG'|'TAX'|'ETC', receivedAt?: Date }
 */
function saveAttachmentShallow_(userFolder, blob, opts = {}) {
  const receivedAt = opts.receivedAt || new Date();
  const yyyymm = yyyymmFromDate_(receivedAt);

  const rawName = blob.getName() || 'file';
  const ext = (rawName.split('.').pop() || 'bin').toLowerCase();
  const type = detectTypeCode_(rawName, opts.hintedType);
  const rule = ATTACH_RULE[type] || ATTACH_RULE.ETC;

  const catFolder = getOrCreateFolder(userFolder, rule.folder);
  const base = `${yyyymm}_${type}`;
  const finalName = uniqueNameInFolder_(catFolder, base, ext);

  const file = catFolder.createFile(blob);
  file.setName(finalName);
  return file;
}

// _form_logs フォルダ（BAS配下）の確保
function ensureFormLogsFolder_() {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID); // BAS_提出書類 のID
  return getOrCreateFolder(root, '_form_logs');
}

// 画像を“公開直リンク”に
function ensurePublicImageUrl_(file) {
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  const id = file.getId();
  // usercontent ドメインが安定
  return `https://drive.usercontent.google.com/u/0/uc?id=${id}&export=download`;
}

// 抽出API呼び出しの共通関数
function postExtract_(fileId, imageUrl, ocrText, lineId) {
  const url = NEXT_API_URL;
  const secret = SECRET || 'FM-BAS';
  const payload = { imageUrl, ocrText, lineId, sourceId: fileId };

  const resp = UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    headers: { 'X-Secret': secret },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true,
    followRedirects: true,
    validateHttpsCertificates: true,
    escaping: false,
    // ← timeout はサポートされないので入れない
  });

  const status = resp.getResponseCode();
  const text = resp.getContentText();

  try {
    const json = JSON.parse(text);
    return { status, raw: text, ...json };
  } catch (e) {
    return { ok: false, status, error: String(e), raw: text };
  }
}

// LINE IDが取れない場合のステージング取得関数
function ensureStagingPath_(submitYm, submissionId, docTypeName) {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const sRoot = getOrCreateFolder(root, '_staging');
  const ym = getOrCreateFolder(sRoot, submitYm);
  const sub = getOrCreateFolder(ym, `submission_${submissionId || 'noid'}`);
  return getOrCreateFolder(sub, docTypeName || '未分類');
}

// Staging のベース（カテゴリはこの下で作る）
function ensureStagingBasePath_(submitYm, submissionId) {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const sRoot = getOrCreateFolder(root, '_staging');
  const ym = getOrCreateFolder(sRoot, submitYm);
  return getOrCreateFolder(ym, `submission_${submissionId || 'noid'}`);
}

/********** ユーティリティ **********/
function fmt(d) {
  return Utilities.formatDate(d, ASIA_TOKYO, 'yyyy-MM-dd HH:mm:ss');
}
function tsKey(d) {
  return Utilities.formatDate(d, ASIA_TOKYO, 'yyyyMMdd_HHmmss');
}
function sanitize(s) {
  return String(s || '')
    .replace(/[\\/:*?"<>|]/g, '_')
    .trim();
}
function getOrCreateFolder(parent, name) {
  const nm = sanitize(name || 'unknown');
  const it = parent.getFoldersByName(nm);
  return it.hasNext() ? it.next() : parent.createFolder(nm);
}
function ensureLabels() {
  GmailApp.getUserLabelByName(LABEL_TO_PROCESS) || GmailApp.createLabel(LABEL_TO_PROCESS);
  GmailApp.getUserLabelByName(LABEL_PROCESSED) || GmailApp.createLabel(LABEL_PROCESSED);
}
function getOrCreateSheet(ss, name, header) {
  const sh = ss.getSheetByName(name) || ss.insertSheet(name);
  if (sh.getLastRow() === 0 && header && header.length) sh.appendRow(header);
  return sh;
}

// ---- email secondary key & dedupe ----
function normalizeEmail_(s) {
  return String(s || '')
    .trim()
    .toLowerCase();
}
function _hex(bytes) {
  return bytes.map((b) => ('0' + (b & 0xff).toString(16)).slice(-2)).join('');
}
function emailHash_(email) {
  const e = normalizeEmail_(email);
  if (!e) return '';
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, e);
  return _hex(digest).slice(0, 16);
}
function pickEmail(fields) {
  const keys = ['メール', 'メールアドレス', 'email', 'e-mail', 'mail', 'Email'];
  for (const k of keys) {
    if (fields && fields[k]) return normalizeEmail_(fields[k]);
  }
  return '';
}

function ensureEmailStagingPath_(submitYm, emailHash, docTypeName) {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const eRoot = getOrCreateFolder(root, '_email_staging');
  const ym = getOrCreateFolder(eRoot, submitYm);
  const eh = getOrCreateFolder(ym, emailHash || 'noemail');
  return getOrCreateFolder(eh, docTypeName || '未分類');
}

// email staging のベース（カテゴリはこの下で作る）
function ensureEmailStagingBasePath_(submitYm, emailHash) {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const eRoot = getOrCreateFolder(root, '_email_staging');
  const ym = getOrCreateFolder(eRoot, submitYm);
  return getOrCreateFolder(ym, emailHash || 'noemail');
}
function contentHashHex_(blob) {
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, blob.getBytes());
  return _hex(digest);
}
function findExistingByHash_(folder, contentHash) {
  const it = folder.getFiles();
  while (it.hasNext()) {
    const f = it.next();
    if ((f.getDescription() || '').indexOf(`content_hash=${contentHash}`) >= 0) return f;
  }
  return null;
}
function countExistingWithBase_(folder, base) {
  let c = 0;
  const re = new RegExp(
    '^' + base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?:_\\d{2})?\\.[A-Za-z0-9]{1,6}$',
    'i'
  );
  const it = folder.getFiles();
  while (it.hasNext()) {
    if (re.test(it.next().getName())) c++;
  }
  return c;
}

/** _email_staging からユーザーフォルダへ統合 */
function reconcileEmailToUser_(lineId, displayName, email, submitYm) {
  const e = normalizeEmail_(email || '');
  if (!e) return;
  const eh = emailHash_(e);
  if (!eh) return;

  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const stagingRoot = getOrCreateFolder(root, '_email_staging');
  const ymFolder = getOrCreateFolder(stagingRoot, submitYm);
  // email_hash 階層が無ければ終わり
  const itEh = ymFolder.getFoldersByName(eh);
  if (!itEh.hasNext()) return;

  const srcEmailFolder = itEh.next(); // <YYYY-MM>/<email_hash>
  const userFolder = getOrCreateUserFolder(root, lineId, displayName || '');

  // docType 階層ごとに移動（年月フォルダは作らない）
  const docTypes = srcEmailFolder.getFolders();
  while (docTypes.hasNext()) {
    const docTypeFolder = docTypes.next(); // 例: "給与明細"
    const destType = getOrCreateFolder(userFolder, docTypeFolder.getName());

    // ファイルごとに重複チェックして移動（宛先はカテゴリ直下）
    const files = docTypeFolder.getFiles();
    while (files.hasNext()) {
      const f = files.next();
      const desc = f.getDescription() || '';
      const m = desc.match(/content_hash=([0-9a-f]{64})/i);
      const ch = m ? m[1] : '';
      const dup = ch ? findExistingByHash_(destType, ch) : null;
      if (!dup) {
        destType.addFile(f);
        srcEmailFolder.removeFile(f);
      }
    }
    // 空になったら片付け（任意）
    if (!docTypeFolder.getFiles().hasNext()) srcEmailFolder.removeFolder(docTypeFolder);
  }
  // email_hash フォルダが空なら片付け（任意）
  if (!srcEmailFolder.getFolders().hasNext() && !srcEmailFolder.getFiles().hasNext()) {
    ymFolder.removeFolder(srcEmailFolder);
  }
}

/** 本文から「【項目名】↵（先頭が空白）ファイル名」を列挙 */
function extractLabelFilenamePairsFromBody_(body) {
  const lines = String(body || '').split(/\r?\n/);
  const out = [];
  let current = null;
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const t = raw.trim();
    const m = t.match(/^【(.+?)】$/);
    if (m) {
      current = m[1].trim();
      continue;
    }
    if (current && /^[　\s]/.test(raw)) {
      const fname = t;
      if (fname) out.push({ label: current, filename: fname });
    }
  }
  return out; // [{label:'給与明細', filename:'テスト給料明細1.PNG'}]
}

/** DOC_MAP から辞書を作る */
function buildDocDict_() {
  const norm = (s) => (s || '').toLowerCase().replace(/\s+/g, '').replace(/[　]+/g, '');
  const labelToTypeCode = {};
  const typeToCode = {};
  const normTypeToType = {};
  DOC_MAP.forEach((e) => {
    typeToCode[e.type] = e.code;
    normTypeToType[norm(e.type)] = e.type;
    (e.labels || []).forEach((l) => {
      labelToTypeCode[norm(l)] = { type: e.type, code: e.code };
      normTypeToType[norm(l)] = e.type;
    });
  });
  return { labelToTypeCode, typeToCode, normTypeToType, norm };
}

/** ペア照合（完全一致→拡張子抜き一致→部分一致） */
function matchByPairs_(originalName, pairs, labelToTypeCode) {
  const norm = (s) => (s || '').toLowerCase().replace(/\s+/g, '').replace(/[　]+/g, '');
  const on = norm(originalName);
  const rmExt = (s) => s.replace(/\.[A-Za-z0-9]{1,6}$/, '');
  let p = pairs.find((pr) => norm(pr.filename) === on);
  if (p) return { ...(labelToTypeCode[norm(p.label)] || {}), fromName: p.filename };
  p = pairs.find(
    (pr) => rmExt(norm(pr.filename)) === rmExt(on) || on.includes(rmExt(norm(pr.filename)))
  );
  if (p) return { ...(labelToTypeCode[norm(p.label)] || {}), fromName: p.filename };
  return null;
}

/** ファイル名ヒューリスティック（保険） */
function guessTypeNameByFilename_(name) {
  const s = String(name || '').toLowerCase();
  if (/salary|pay.?slip|給与|給料|給與|明細/.test(s)) return '給与明細';
  if (/bank|通帳|残高|入出金|statement/.test(s)) return '銀行通帳';
  if (/家計|収支|budget/.test(s)) return '家計収支表';
  return null;
}

/** 対象YYYYMM抽出 */
function guessPeriod_(s) {
  if (!s) return '';
  for (const p of PERIOD_PATS) {
    const m = String(s).match(p.pat);
    if (m) return p.to.apply(null, m.slice(1));
  }
  return '';
}

/********** パース **********/
function parseMetaAndFields(msg) {
  const subject = msg.getSubject() || '';
  const bodyPlain = msg.getPlainBody() || '';
  const bodyHtml = msg.getBody() || '';
  const body = bodyPlain || bodyHtml;

  const subjectLine = (subject.match(RX_SUBJECT_LINE) || [])[1] || '';
  const subjectSid = (subject.match(RX_SUBJECT_SID) || [])[1] || '';
  const subjectSecretOK = RX_SUBJECT_SECRET.test(subject);

  const metaBlock = (body.match(RX_META_BLOCK) || [])[1] || '';
  const meta = {};
  let m;
  while ((m = RX_META_KV.exec(metaBlock)) !== null) {
    meta[m[1].toLowerCase()] = m[2];
  }

  // まずは従来の FIELDS ブロック
  const fields = {};
  let f;
  const fieldsBlock = (body.match(RX_FIELDS_BLOCK) || [])[1] || '';
  while ((f = RX_FIELD_LINE.exec(fieldsBlock)) !== null) {
    const label = sanitize(f[1]);
    fields[label] = f[2] || '';
  }

  // ★フォールバック：メール本文全体から「【ラベル】 値」を拾う（FIELDSブロックが無いとき）
  if (Object.keys(fields).length === 0) {
    const RX_INLINE = /【(.+?)】\s*([^\n\r]+)/g;
    let g;
    while ((g = RX_INLINE.exec(body)) !== null) {
      const k = sanitize(g[1]);
      const v = (g[2] || '').trim();
      if (k && v) fields[k] = v;
    }
  }

  const line_id = sanitize(meta.line_id || subjectLine || '');
  const form_name = sanitize(meta.form_name || '');
  const submission_id = sanitize(meta.submission_id || subjectSid || '');
  const submitted_at = meta.submitted_at || '';
  const seq = meta.seq || '';
  const referrer = meta.referrer || '';
  const secretOK = (meta.secret || '').trim() === SECRET && subjectSecretOK;

  return {
    subject,
    body,
    line_id,
    form_name,
    submission_id,
    submitted_at,
    seq,
    referrer,
    secretOK,
    fields,
  };
}

/********** 添付保存 + JSON保存 **********/
function saveAttachmentsAndJson(meta, msg) {
  const when = msg.getDate();
  const submitYm = Utilities.formatDate(when, ASIA_TOKYO, 'yyyy-MM'); // 提出月（送信日時）
  const submissionId = meta.submission_id || 'SUB' + tsKey(when).replace(/[^0-9]/g, '');
  const display = pickDisplayName(meta.fields);
  const body = meta.body || msg.getPlainBody() || msg.getBody() || '';

  // LINEが分かった & メールも分かる場合は、先に email_staging をユーザーフォルダへ統合
  const emailNow = pickEmail(meta.fields);
  if (meta.line_id && emailNow) {
    try {
      reconcileEmailToUser_(meta.line_id, display || '', emailNow, submitYm);
    } catch (_) {}
  }

  // 本文の「【項目名】↔ファイル名」ペアと辞書
  const pairs = extractLabelFilenamePairsFromBody_(body);
  const maps = buildDocDict_();

  // 添付ごとに「日本語フォルダ」「英数字ファイル名」で保存
  const saved = [];
  const seqCounter = {}; // docCode|ymForName -> seq
  const atts = msg.getAttachments({ includeInlineImages: false, includeAttachments: true }) || [];

  atts.forEach((att) => {
    if (att.isGoogleType()) return;
    const original = att.getName();
    const ext = (original.match(/(\.[A-Za-z0-9]{1,6})$/)?.[1] || '').toLowerCase();
    const blob = att.copyBlob();
    const cHash = contentHashHex_(blob);

    // 1) TYPE推定（本文ペア→ファイル名ヒューリスティック）
    const hit = matchByPairs_(original, pairs, maps.labelToTypeCode);
    const hinted = hit?.code || '';
    const typeCode = detectTypeCode_(original, hinted);
    const rule = ATTACH_RULE[typeCode] || ATTACH_RULE.ETC;
    const typeName = rule.folder;
    const period = yyyymmFromDate_(when);

    // 2) 保存先のベース（LINE > email > _staging）
    const email = pickEmail(meta.fields);
    const emailH = emailHash_(email);
    let baseFolder;
    if (meta.line_id) {
      const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
      baseFolder = getOrCreateUserFolder(root, meta.line_id, display || '');
    } else if (emailH) {
      baseFolder = ensureEmailStagingBasePath_(submitYm, emailH);
    } else {
      baseFolder = ensureStagingBasePath_(submitYm, submissionId);
    }

    // 3) カテゴリフォルダ（カテゴリ直下）
    const dest = getOrCreateFolder(baseFolder, typeName);

    // 4) 重複チェック（content_hash）
    const existed = findExistingByHash_(dest, cHash);
    if (existed) {
      // ★ デデュープでも submissions / contacts を記録する
      appendSubmissionLog_({
        line_id: meta.line_id || '',
        email: pickEmail(meta.fields) || '',
        submission_id: submissionId,
        form_name: meta.form_name || '',
        submit_ym: submitYm,
        doc_code: typeCode,
        period_yyyymm: period || '',
        drive_file_id: existed.getId(),
        file_name: existed.getName(),
        folder_path: dest.getName(),
        content_hash: cHash || '',
      });
      upsertContactLegacy_({
        line_id: meta.line_id || '',
        email: pickEmail(meta.fields) || '',
        display_name: display || '',
        last_form: meta.form_name || '',
        last_submit_ym: submitYm,
      });
      saved.push({
        id: existed.getId(),
        name: existed.getName(),
        size: existed.getSize(),
        folderId: dest.getId(),
        doc_type: typeName,
        doc_code: typeCode,
        period_yyyymm: period || '',
        dedup: true,
      });
      return;
    }
    // 5) 保存（saveAttachmentShallow_を使用）
    const file = saveAttachmentShallow_(baseFolder, blob.setName(original), {
      hintedType: typeCode,
      receivedAt: when,
    });
    file.setDescription(
      [
        `original=${original}`,
        `doc_type=${typeName}`,
        `doc_code=${typeCode}`,
        `period=${period || ''}`,
        `submitted_at=${Utilities.formatDate(when, ASIA_TOKYO, "yyyy-MM-dd'T'HH:mm:ssXXX")}`,
        `submission_id=${submissionId}`,
        `form_id=${meta.form_name || ''}`,
        `line_id=${meta.line_id || ''}`,
        `email=${email || ''}`,
        `email_hash=${emailH || ''}`,
        `staged=${meta.line_id ? 'false' : email ? 'email' : 'true'}`,
        `content_hash=${cHash}`,
      ].join('\n')
    );

    appendSubmissionLog_({
      line_id: meta.line_id || '',
      email: pickEmail(meta.fields) || '',
      submission_id: submissionId,
      form_name: meta.form_name || '',
      submit_ym: submitYm,
      doc_code: typeCode,
      period_yyyymm: period || '',
      drive_file_id: file.getId(),
      file_name: file.getName(),
      folder_path: file.getParents().hasNext() ? file.getParents().next().getName() : '',
      content_hash: cHash || '', // 既に計算済みならその値、無ければ空でも動く
    });

    upsertContactLegacy_({
      line_id: meta.line_id || '',
      email: pickEmail(meta.fields) || '',
      display_name: display || '',
      last_form: meta.form_name || '',
      last_submit_ym: submitYm,
    });

    saved.push({
      id: file.getId(),
      name: file.getName(),
      size: att.getSize(),
      folderId: file.getParents().hasNext() ? file.getParents().next().getId() : '',
      doc_type: typeName,
      doc_code: typeCode,
      period_yyyymm: period || '',
    });
  });

  // 7) JSON保存：submission_logs フォルダは廃止。ユーザーフォルダ直下へ <formkey>__<submissionId>.json
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  let jsonParent;
  let folderIdForReturn = '';
  if (meta.line_id) {
    const uf = getOrCreateUserFolder(root, meta.line_id, display || '');
    jsonParent = uf;
    folderIdForReturn = uf.getId();
  } else {
    // LINEなし時は、最初の保存先フォルダ（email staging or _staging）に置く
    const first = saved[0];
    jsonParent = first
      ? DriveApp.getFolderById(first.folderId)
      : ensureStagingPath_(submitYm, submissionId, '未分類');
    folderIdForReturn = first ? first.folderId : jsonParent.getId();
  }
  const jsonFile = saveSubmissionJsonShallow_(
    jsonParent,
    submissionId,
    body,
    meta.fields,
    meta.subject || '',
    meta.line_id || ''
  );

  return { folderId: folderIdForReturn, savedFiles: saved, jsonId: jsonFile.getId() };
}

/********** 台帳＆顧客表 更新 **********/
function updateLedgers(meta, saved) {
  const ss = openOrCreateMaster_();

  // submissions
  const shSub = getOrCreateSheet(ss, 'submissions', [
    'ts_saved',
    'line_id',
    'form_name',
    'submission_id',
    'seq',
    'saved_file_ids',
    'json_id',
  ]);
  shSub.appendRow([
    fmt(new Date()),
    meta.line_id,
    meta.form_name,
    meta.submission_id,
    meta.seq,
    (saved.savedFiles || []).map((s) => s.id).join(','),
    saved.jsonId,
  ]);

  // customers（display_name は今回 fields から推定：候補ラベルを優先順で）
  const nameCandidates = ['名前', '氏名', 'お名前', 'フルネーム'];
  let display = '';
  for (const key of nameCandidates) {
    if (meta.fields[key]) {
      display = meta.fields[key];
      break;
    }
  }
  const shCus = getOrCreateSheet(ss, 'customers', [
    'line_id',
    'display_name',
    'first_seen_at',
    'last_seen_at',
    'last_form',
  ]);
  const lastRow = shCus.getLastRow();
  const all = lastRow > 1 ? shCus.getRange(2, 1, lastRow - 1, 5).getValues() : [];
  let found = false;
  for (let i = 0; i < all.length; i++) {
    if (String(all[i][0]) === meta.line_id) {
      // 更新
      shCus.getRange(i + 2, 2).setValue(display || all[i][1]); // display_name
      shCus.getRange(i + 2, 4).setValue(fmt(new Date())); // last_seen_at
      shCus.getRange(i + 2, 5).setValue(meta.form_name); // last_form
      found = true;
      break;
    }
  }
  if (!found) {
    shCus.appendRow([
      meta.line_id,
      display || '',
      fmt(new Date()),
      fmt(new Date()),
      meta.form_name,
    ]);
  }
}

/********** メイン処理 **********/
function processLabel(labelName) {
  const labelToProcess = GmailApp.getUserLabelByName(labelName);
  if (!labelToProcess) return;

  const labelProcessed =
    GmailApp.getUserLabelByName(LABEL_PROCESSED) || GmailApp.createLabel(LABEL_PROCESSED);

  const threads = labelToProcess.getThreads(0, 50); // 1回で最大50スレッド
  threads.forEach((thread) => {
    // すでに処理済みラベルがスレッドについていたらスキップ
    const alreadyProcessed = thread.getLabels().some((l) => l.getName() === LABEL_PROCESSED);
    if (alreadyProcessed) return;

    let anySaved = false;

    // スレッド内の各メッセージを確認（最新だけで十分なら最後の1通だけ処理でもOK）
    thread.getMessages().forEach((msg) => {
      // 添付が無くても JSON は作る運用（必要ならここで atts.length==0 の場合でも続行）
      const meta = parseMetaAndFields(msg);

      // 検印（件名 [#FM-BAS] & META の secret: FM-BAS の両方）
      if (!meta.secretOK) return;

      // フォーム回答シートの登録＆ショートカット作成（見える置き場を一本化）
      if (meta.form_name) {
        upsertFormLogRegistry_(meta.form_name);
      }

      if (!meta.form_name) meta.form_name = 'unknown_form';

      const saved = saveAttachmentsAndJson(meta, msg);
      anySaved = true;
      // 保存できたファイルに対しOCR（対象フォームのみ）
      ocr_processSaved_(saved, meta);

      // （任意のデバッグ）保存結果をログ
      // Logger.log('saved to folder=' + saved.folderId + ' files=' + (saved.savedFiles||[]).length + ' json=' + saved.jsonId);
    });

    // このスレッドで1通でも保存できたらラベルを更新（スレッド単位）
    if (anySaved) {
      thread.addLabel(labelProcessed);
      thread.removeLabel(labelToProcess);
    }
  });
}

/**
 * Vision API 同期OCR（画像のみ：jpg/jpeg/png）
 * 生成物:
 *  - <元ファイル名>.ocr.txt
 *  - <元ファイル名>.ocr.json
 */
/** 画像(JPG/PNG)にOCRをかけて .ocr.txt / .ocr.json を隣に保存（REST版） */
function ocr_runForImageFile_(file) {
  // 拡張子ではなく MIME で判定（大文字/無拡張でもOK）
  const mt = String(file.getMimeType() || '').toLowerCase();
  if (!/^image\/(png|jpe?g)$/i.test(mt)) return null; // PDF/HEICは別レーン

  // 既に .ocr.txt / .ocr.json があればスキップ
  const parent = file.getParents().hasNext() ? file.getParents().next() : null;
  const base = file.getName();
  if (parent) {
    const hasTxt = parent.getFilesByName(base + '.ocr.txt').hasNext();
    const hasJson = parent.getFilesByName(base + '.ocr.json').hasNext();
    if (hasTxt && hasJson) return 'skipped';
  }

  // Vision OCR 実行
  const body = {
    requests: [
      {
        image: { content: Utilities.base64Encode(file.getBlob().getBytes()) },
        features: [{ type: 'DOCUMENT_TEXT_DETECTION' }],
        imageContext: { languageHints: OCR_LANG_HINTS },
      },
    ],
  };

  const resp = UrlFetchApp.fetch('https://vision.googleapis.com/v1/images:annotate', {
    method: 'post',
    contentType: 'application/json',
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    payload: JSON.stringify(body),
    muteHttpExceptions: true,
  });
  const json = JSON.parse(resp.getContentText());
  const text = json?.responses?.[0]?.fullTextAnnotation?.text || '';

  if (parent) {
    parent.createFile(Utilities.newBlob(text, 'text/plain', base + '.ocr.txt'));
    parent.createFile(
      Utilities.newBlob(JSON.stringify(json, null, 2), 'application/json', base + '.ocr.json')
    );
  }
  return text;
}

/**
 * OCRテキストから給与明細の主要項目をザックリ抽出（PoC用）
 * ※ 後でパターン強化＆正規化予定
 */
function _toHalf(s) {
  return String(s || '').replace(/[！-～]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
}
function _num(s) {
  if (!s) return '';
  s = _toHalf(s)
    .replace(/[,\s　]/g, '')
    .replace(/(\d+)\.(\d{3})(?!\d)/g, '$1$2')
    .replace(/円.*$/, '')
    .replace(/[^\d\-]/g, '');
  return s ? String(parseInt(s, 10)) : '';
}
function _eraToISO(s) {
  s = _toHalf(s);
  const m = s.match(/(令和|平成)\s*(\d{1,2})年\s*(\d{1,2})月\s*(\d{1,2})?日/);
  if (!m) return '';
  const y = (m[1] === '令和' ? 2018 : 1988) + +m[2];
  const pad = (n) => ('0' + n).slice(-2);
  return `${y}-${pad(+m[3])}-${pad(+(m[4] || '1'))}`;
}
function _pickDate(text) {
  const t = text || '';
  let m = t.match(
    /(令和|平成)\s*[0-9０-９]{1,2}年\s*[0-9０-９]{1,2}月\s*[0-9０-９]{1,2}日[^。\n]*支給/
  );
  if (m) {
    const iso = _eraToISO(m[0]);
    if (iso) return iso;
  }
  m = t.match(
    /(支給日|支給年月日)[：:\s]*([0-9０-９]{4}[/\-年][0-9０-９]{1,2}[/\-月][0-9０-９]{1,2}日?)/
  );
  if (m) {
    return _toHalf(m[2])
      .replace(/[年月]/g, '-')
      .replace(/日/g, '')
      .replace(/\/+/g, '-');
  }
  m = t.match(/(令和|平成)\s*[0-9０-９]{1,2}年\s*[0-9０-９]{1,2}月\s*[0-9０-９]{1,2}日/);
  if (m) {
    const iso = _eraToISO(m[0]);
    if (iso) return iso;
  }
  return '';
}
function ocr_extractPayslip_(text) {
  const t = text || '';
  const pick = (alts) => {
    for (const re of alts) {
      const m = t.match(re);
      if (m) return (m[2] || m[1] || '').trim();
    }
    return '';
  };
  const obj = {
    company: pick([/(会社名|勤務先名|事業所名)[：:]\s*([^\n]+)/i, /^(.+?株式会社)[^\n]*$/m]),
    employee: pick([/(氏名|従業員名|社員名|お名前)[：:]\s*([^\n]+)/i]),
    payday: _pickDate(t),
    gross: _num(pick([/(実総支給額|総支給額|総支給|支給合計)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    deduction: _num(pick([/(総控除額|控除合計|控除額)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    net: _num(pick([/(差引支給額|差引額|手取|支給額)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    baseSalary: _num(pick([/(基本給)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    commute: _num(
      pick([/(通勤手当|通勤費|通勤手当\(課\)|通勤手当\(非\))[：:\s]*([0-9０-９,，\.]+)円?/i])
    ),
    healthIns: _num(pick([/(健康保険|健保)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    pension: _num(pick([/(厚生年金|年金)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    tax: _num(pick([/(源泉所得税|所得税)[：:\s]*([0-9０-９,，\.]+)円?/i])),
    residentTax: _num(pick([/(住民税)[：:\s]*([0-9０-９,，\.]+)円?/i])),
  };
  if (obj.payday && +obj.payday.slice(0, 4) < 2015) obj.payday = ''; // 明らかな誤年を弾く
  return obj;
}

/**
 * 抽出結果を <元ファイル名>.extracted.json として保存
 */
function ocr_saveExtraction_(file, extracted) {
  if (!extracted) return;
  const parent = file.getParents().hasNext() ? file.getParents().next() : null;
  if (!parent) return;
  parent.createFile(
    Utilities.newBlob(
      JSON.stringify(extracted, null, 2),
      'application/json',
      file.getName() + '.extracted.json'
    )
  );
}

/**
 * 保存直後のファイル群に対しOCR→抽出まで実行
 * @param {Object} saved saveAttachmentsAndJson の戻り値
 * @param {Object} meta  parseMetaAndFields の結果
 */
function ocr_processSaved_(saved, meta) {
  try {
    const form = String(meta.form_name || '');
    if (OCR_TARGET_FORMS.length > 0 && !OCR_TARGET_FORMS.some((k) => form.includes(k))) return;

    (saved.savedFiles || []).forEach((s) => {
      const file = DriveApp.getFileById(s.id);
      const parent = file.getParents().hasNext() ? file.getParents().next() : null;
      if (!parent) return;

      // 既に _model.json があればスキップ（再生成したい時は削除してから）
      if (parent.getFilesByName(s.id + '_model.json').hasNext()) return;

      // まずOCRを試みる（既存あれば 'skipped'）
      let text = ocr_runForImageFile_(file);

      // skippedなら既存の .ocr.txt を読み込む（なければ空でOK→画像のみで抽出）
      if (text === 'skipped') {
        const it = parent.getFilesByName(file.getName() + '.ocr.txt');
        text = it.hasNext() ? it.next().getBlob().getDataAsString('utf-8') : '';
      }

      // （任意）PoC抽出：text があれば .extracted.json を更新
      if (text) {
        const extracted = ocr_extractPayslip_(text);
        ocr_saveExtraction_(file, extracted);
      }

      // 画像URLを公開にして抽出APIにPOST（ocrTextは空でもOK）
      const imageUrl = ensurePublicImageUrl_(file);
      const out = postExtract_(s.id, imageUrl, text || '', meta.line_id);

      // 成果物保存
      if (out && out.ok && out.data) {
        parent.createFile(
          Utilities.newBlob(
            JSON.stringify(out.data, null, 2),
            'application/json',
            s.id + '_model.json'
          )
        );
      } else {
        parent.createFile(
          Utilities.newBlob(
            `status=${out?.status}\n${out?.error || ''}\n\n${out?.raw || ''}`,
            'text/plain',
            s.id + '_extract_error.txt'
          )
        );
      }
    });
  } catch (e) {
    console.error('OCR処理エラー:', e);
  }
}

/********** エントリ **********/
function cron_1min() {
  ensureLabels();
  processLabel(LABEL_TO_PROCESS);
}

function pickDisplayName(fields) {
  const keys = ['名前', '氏名', 'お名前', 'フルネーム', 'Name'];
  for (const k of keys) {
    if (fields && fields[k]) return sanitize(fields[k]);
  }
  return '';
}

/** ====== caseId 導入: ブートストラップ最小実装 ====== */
function json_(obj, code) {
  const out = ContentService.createTextOutput(JSON.stringify(obj));
  out.setMimeType(ContentService.MimeType.JSON);
  if (typeof out.setStatusCode === 'function') {
    out.setStatusCode(code || 200);
    return out;
  }
  return out; // Apps Script では setStatusCode が使えない WebApp 環境があるため冪等
}

function verifySig_(base, sigHex) {
  const secret = PropertiesService.getScriptProperties().getProperty('BOOTSTRAP_SECRET') || '';
  const raw = Utilities.computeHmacSha256Signature(String(base || ''), secret);
  const hex = raw.map((b) => ('0' + (b & 0xff).toString(16)).slice(-2)).join('');
  return hex === String(sigHex || '');
}

function makeUserKey_(lineId) {
  return String(lineId || '')
    .slice(0, 6)
    .toLowerCase();
}

function ensureUserRootFolder_(displayName, userKey) {
  const parent = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const name = `${sanitize(displayName || '')}__${sanitize(userKey || '')}`;
  const it = parent.getFoldersByName(name);
  if (it.hasNext()) {
    const f = it.next();
    // attachments サブフォルダが無ければ作成
    const att = f.getFoldersByName('attachments');
    if (!att.hasNext()) f.createFolder('attachments');
    return f;
  }
  // attachments を作ってから親に戻る＝親はユーザフォルダ
  return parent.createFolder(name).createFolder('attachments').getParents().next();
}

function upsertContact_(ss, lineId, displayName) {
  const sh = ss.getSheetByName('contacts') || ss.insertSheet('contacts');
  if (sh.getLastRow() === 0)
    sh.appendRow([
      'lineId',
      'displayName',
      'userKey',
      'rootFolderId',
      'nextCaseSeq',
      'activeCaseId',
    ]);

  // 既存ヘッダのマップを作成（両表記サポート）
  const values = sh.getDataRange().getValues();
  const header = values[0] || [];
  const idx = header.reduce((m, v, i) => ((m[String(v)] = i), m), {});

  // 必要列が無ければ末尾に追加
  const ensureCols = [
    'lineId',
    'displayName',
    'userKey',
    'rootFolderId',
    'nextCaseSeq',
    'activeCaseId',
  ];
  ensureCols.forEach((k) => {
    if (!(k in idx)) {
      sh.insertColumnAfter(sh.getLastColumn());
      sh.getRange(1, sh.getLastColumn()).setValue(k);
      idx[k] = sh.getLastColumn() - 1; // 再取得は省略（この場では未使用のため）
    }
  });

  // 既存行検索（lineId）
  let row = -1;
  const colLineId = idx.lineId !== undefined ? idx.lineId : idx['line_id'];
  const colDisplay = idx.displayName !== undefined ? idx.displayName : idx['display_name'];
  for (let r = 1; r < values.length; r++) {
    if (String(values[r][colLineId] || '') === String(lineId)) {
      row = r;
      break;
    }
  }

  if (row === -1) {
    const userKey = makeUserKey_(lineId);
    const root = ensureUserRootFolder_(displayName, userKey);
    // 既存ヘッダの並びに合わせて行を構築
    const rowVals = new Array(sh.getLastColumn()).fill('');
    rowVals[colLineId] = lineId;
    if (colDisplay !== undefined) rowVals[colDisplay] = displayName;
    rowVals[idx.userKey] = userKey;
    rowVals[idx.rootFolderId] = root.getId();
    rowVals[idx.nextCaseSeq] = 0;
    rowVals[idx.activeCaseId] = '';
    sh.appendRow(rowVals);
    return {
      lineId,
      displayName,
      userKey,
      rootFolderId: root.getId(),
      nextCaseSeq: 0,
      activeCaseId: '',
    };
  } else {
    const userKey = values[row][idx.userKey] || makeUserKey_(lineId);
    const rootId =
      values[row][idx.rootFolderId] || ensureUserRootFolder_(displayName, userKey).getId();
    return {
      lineId,
      displayName: values[row][colDisplay] || displayName,
      userKey,
      rootFolderId: rootId,
      nextCaseSeq: values[row][idx.nextCaseSeq] || 0,
      activeCaseId: values[row][idx.activeCaseId] || '',
    };
  }
}

function allocateNextCaseId_(lineId) {
  const ss = openOrCreateMaster_();
  const sh = ss.getSheetByName('contacts');
  const values = sh.getDataRange().getValues();
  const header = values[0] || [];
  const idx = header.reduce((m, v, i) => ((m[String(v)] = i), m), {});
  for (let r = 1; r < values.length; r++) {
    const colLineId = idx.lineId !== undefined ? idx.lineId : idx['line_id'];
    const colNext = idx.nextCaseSeq;
    if (String(values[r][colLineId]) === String(lineId)) {
      let cur = parseInt(values[r][idx.nextCaseSeq] || 0, 10);
      if (isNaN(cur)) cur = 0;
      const next = cur + 1;
      const padded = String(next).padStart(4, '0');
      sh.getRange(r + 1, colNext + 1).setValue(next);
      return padded;
    }
  }
  throw new Error('lineId not found in contacts');
}

function setActiveCaseId_(ss, lineId, caseId) {
  const sh = ss.getSheetByName('contacts');
  const values = sh.getDataRange().getValues();
  const header = values[0] || [];
  const idx = header.reduce((m, v, i) => ((m[String(v)] = i), m), {});
  for (let r = 1; r < values.length; r++) {
    const colLineId = idx.lineId !== undefined ? idx.lineId : idx['line_id'];
    const colActive = idx.activeCaseId;
    if (String(values[r][colLineId]) === String(lineId)) {
      sh.getRange(r + 1, colActive + 1).setValue(caseId);
      return;
    }
  }
}

function casesAppend_(lineId, caseId) {
  const ss = openOrCreateMaster_();
  const sh = ss.getSheetByName('cases') || ss.insertSheet('cases');
  if (sh.getLastRow() === 0)
    sh.appendRow(['lineId', 'caseId', 'createdAt', 'status', 'lastActivity']);
  const now = new Date();
  sh.appendRow([lineId, caseId, now, 'draft', now]);
}

function resolveCaseId_(mailPlainBody, subject, lineId) {
  const meta = parseMetaBlock_(mailPlainBody);
  if (meta.case_id) return String(meta.case_id).trim();
  const ss = openOrCreateMaster_();
  const sh = ss.getSheetByName('contacts');
  const values = sh.getDataRange().getValues();
  const header = values[0] || [];
  const idx = header.reduce((m, v, i) => ((m[String(v)] = i), m), {});
  for (let r = 1; r < values.length; r++) {
    const colLineId = idx.lineId !== undefined ? idx.lineId : idx['line_id'];
    const colActive = idx.activeCaseId;
    if (String(values[r][colLineId]) === String(lineId)) {
      const active = values[r][colActive] || '';
      return String(active || '');
    }
  }
  return '';
}

function doPost(e) {
  try {
    const req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const { lineId, displayName, ts, sig } = req || {};
    if (!verifySig_(String(lineId || '') + '|' + String(ts || ''), sig)) {
      return json_({ error: 'bad_sig' }, 403);
    }
    const ss = openOrCreateMaster_();
    const contact = upsertContact_(ss, lineId, displayName);
    let active = contact.activeCaseId;
    if (!active) {
      active = allocateNextCaseId_(lineId);
      setActiveCaseId_(ss, lineId, active);
      casesAppend_(lineId, active);
    }
    return json_(
      { userKey: contact.userKey, activeCaseId: active, rootFolderId: contact.rootFolderId },
      200
    );
  } catch (err) {
    return json_({ error: String(err) }, 500);
  }
}

function inferDisplayNameFromLedger_(lineId) {
  try {
    const ss = openOrCreateMaster_();
    const sh = ss.getSheetByName('customers');
    if (!sh) return '';
    const vals = sh.getDataRange().getValues(); // [line_id, display_name, ...]
    for (let i = 1; i < vals.length; i++) {
      if (String(vals[i][0]) === String(lineId)) return sanitize(vals[i][1] || '');
    }
  } catch (_) {}
  return '';
}

function getOrCreateUserFolder(root, lineId, displayName) {
  const base = sanitize(lineId || 'unknown');

  // displayName が空なら台帳から補完を試みる
  let disp = sanitize(displayName || '') || inferDisplayNameFromLedger_(base);
  const named = disp ? (disp + '__' + base).slice(0, FOLDER_NAME_MAX) : '';

  // 1) 完全一致をまず探す（named → base）
  if (named) {
    const itNamed = root.getFoldersByName(named);
    if (itNamed.hasNext()) return itNamed.next();
  }
  const itBase = root.getFoldersByName(base);
  if (itBase.hasNext()) {
    const f = itBase.next();
    // 氏名が分かっていて、方針が 'latest' ならリネーム
    if (disp && RENAME_STRATEGY === 'latest') {
      if (!root.getFoldersByName(named).hasNext()) f.setName(named);
    }
    return f;
  }

  // 2) "*__lineId" を総当たりで探す（フォームB→Aパターン対策）
  //   ※ フォルダ数が極端に多い環境で重ければ early return に変更してください
  const all = root.getFolders();
  let match = null;
  while (all.hasNext()) {
    const f = all.next();
    const nm = f.getName();
    if (nm.endsWith('__' + base)) {
      match = f;
      break;
    }
  }
  if (match) {
    // 氏名が取れていて 'latest' なら名前を更新
    if (disp && RENAME_STRATEGY === 'latest') {
      const target = named;
      if (target && match.getName() !== target && !root.getFoldersByName(target).hasNext()) {
        match.setName(target);
      }
    }
    return match;
  }

  // 3) どれも無ければ新規作成（氏名があれば named、無ければ base）
  return root.createFolder(named || base);
}

/** /root/<氏名__LINEID>/<日本語書類名>/ を返す（年月フォルダなし） */
function ensurePathJapanese_(lineId, displayName, docTypeName, submitYm) {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const userFolder = getOrCreateUserFolder(root, lineId || 'unknown', displayName || '');
  const typeFolder = getOrCreateFolder(userFolder, docTypeName || '未分類');
  return typeFolder; // 年月フォルダは廃止（浅い構造）
}

/** =========================
 *  BAS_master（状態管理ブック）
 *  contacts / submissions / form_logs をこの1冊に集約
 *  ========================= */
function openOrCreateMaster_() {
  const root = DriveApp.getFolderById(ROOT_FOLDER_ID);
  const it = root.getFilesByName('BAS_master');
  let ss;
  if (it.hasNext()) {
    ss = SpreadsheetApp.openById(it.next().getId());
  } else {
    ss = SpreadsheetApp.create('BAS_master');
    const file = DriveApp.getFileById(ss.getId());
    root.addFile(file);
    DriveApp.getRootFolder().removeFile(file);
  }
  // シートの初期化
  const c = ss.getSheetByName('contacts') || ss.insertSheet('contacts');
  if (c.getLastRow() === 0) {
    c.appendRow([
      'line_id',
      'email',
      'email_hash',
      'display_name',
      'first_seen_at',
      'last_seen_at',
      'last_form',
      'last_submit_ym',
      'notes',
      // 以下、caseId 管理用の列（最小セット）
      'userKey',
      'rootFolderId',
      'nextCaseSeq',
      'activeCaseId',
    ]);
  } else {
    // 既存シートに caseId 管理用の列が無ければ末尾に追加
    const header = c.getRange(1, 1, 1, c.getLastColumn()).getValues()[0];
    const need = ['userKey', 'rootFolderId', 'nextCaseSeq', 'activeCaseId'];
    const missing = need.filter((k) => header.indexOf(k) < 0);
    missing.forEach((name) => {
      c.insertColumnAfter(c.getLastColumn());
      c.getRange(1, c.getLastColumn()).setValue(name);
    });
  }
  const s = ss.getSheetByName('submissions') || ss.insertSheet('submissions');
  if (s.getLastRow() === 0) {
    s.appendRow([
      'ts_saved',
      'line_id',
      'email',
      'submission_id',
      'form_name',
      'submit_ym',
      'doc_code',
      'period_yyyymm',
      'drive_file_id',
      'file_name',
      'folder_path',
      'content_hash',
    ]);
  }
  const f = ss.getSheetByName('form_logs') || ss.insertSheet('form_logs');
  if (f.getLastRow() === 0) {
    f.appendRow([
      'form_name',
      'sheet_id',
      'sheet_url',
      'created_time',
      'shortcut_id',
      'shortcut_url',
      'mirrored',
      'last_seen',
    ]);
  }
  // cases シートの初期化（存在しなければ）
  const cs = ss.getSheetByName('cases') || ss.insertSheet('cases');
  if (cs.getLastRow() === 0) {
    cs.appendRow(['lineId', 'caseId', 'createdAt', 'status', 'lastActivity']);
  }
  return ss;
}

/** contacts を upsert（line_id 優先、なければ email） */
function upsertContactLegacy_({ line_id, email, display_name, last_form, last_submit_ym }) {
  const ss = openOrCreateMaster_();
  const sh = ss.getSheetByName('contacts');
  const vals = sh.getDataRange().getValues();
  const now = Utilities.formatDate(new Date(), ASIA_TOKYO, 'yyyy-MM-dd HH:mm:ss');
  const e = normalizeEmail_(email || '');
  const eh = emailHash_(e);

  // 既存行探索：line_id → email
  let row = -1;
  for (let i = 1; i < vals.length; i++) {
    if (line_id && String(vals[i][0]) === String(line_id)) {
      row = i + 1;
      break;
    }
  }
  if (row < 0 && e) {
    for (let i = 1; i < vals.length; i++) {
      if (normalizeEmail_(vals[i][1]) === e) {
        row = i + 1;
        break;
      }
    }
  }

  if (row < 0) {
    sh.appendRow([
      line_id || '',
      e,
      eh,
      display_name || '',
      now,
      now,
      last_form || '',
      last_submit_ym || '',
      '',
    ]);
  } else {
    if (line_id && !vals[row - 1][0]) sh.getRange(row, 1).setValue(line_id);
    if (e && normalizeEmail_(vals[row - 1][1]) !== e) sh.getRange(row, 2).setValue(e);
    if (eh && vals[row - 1][2] !== eh) sh.getRange(row, 3).setValue(eh);
    if (display_name && (!vals[row - 1][3] || vals[row - 1][3] !== display_name))
      sh.getRange(row, 4).setValue(display_name);
    sh.getRange(row, 6).setValue(now); // last_seen_at
    if (last_form) sh.getRange(row, 7).setValue(last_form);
    if (last_submit_ym) sh.getRange(row, 8).setValue(last_submit_ym);
  }
}

/** submissions へ1行追記 */
function appendSubmissionLog_({
  line_id,
  email,
  submission_id,
  form_name,
  submit_ym,
  doc_code,
  period_yyyymm,
  drive_file_id,
  file_name,
  folder_path,
  content_hash,
}) {
  const ss = openOrCreateMaster_();
  const sh = ss.getSheetByName('submissions');
  if (sh.getLastRow() === 0) {
    sh.appendRow([
      'ts_saved',
      'line_id',
      'email',
      'submission_id',
      'form_name',
      'submit_ym',
      'doc_code',
      'period_yyyymm',
      'drive_file_id',
      'file_name',
      'folder_path',
      'content_hash',
    ]);
  }
  const now = Utilities.formatDate(new Date(), ASIA_TOKYO, 'yyyy-MM-dd HH:mm:ss');
  sh.appendRow([
    now,
    line_id || '',
    normalizeEmail_(email || ''),
    submission_id || '',
    form_name || '',
    submit_ym || '',
    doc_code || '',
    period_yyyymm || '',
    drive_file_id || '',
    file_name || '',
    folder_path || '',
    content_hash || '',
  ]);
}

/** 指定フォルダ以下のツリーをログに出力 */
function debug_showBasTree() {
  logFolderTree(ROOT_FOLDER_ID);
}

function logFolderTree(folderId, depth = 0) {
  const folder = DriveApp.getFolderById(folderId);
  const prefix = '  '.repeat(depth);
  Logger.log(prefix + '📁 ' + folder.getName());

  // ファイル
  const files = folder.getFiles();
  while (files.hasNext()) {
    const f = files.next();
    Logger.log(prefix + '  📄 ' + f.getName());
  }

  // サブフォルダ
  const subs = folder.getFolders();
  while (subs.hasNext()) {
    const sub = subs.next();
    logFolderTree(sub.getId(), depth + 1);
  }
}

function ping_() {
  Logger.log('BAS ping OK');
}
