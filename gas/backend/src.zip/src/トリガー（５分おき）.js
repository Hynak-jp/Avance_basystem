function setupTriggers(){
  const lock = LockService.getScriptLock();
  lock.tryLock(3000);
  try {
    ScriptApp.getProjectTriggers().forEach(t => {
      if (t.getHandlerFunction() === 'cron_1min') ScriptApp.deleteTrigger(t);
    });
    ScriptApp.newTrigger('cron_1min').timeBased().everyMinutes(5).create();
    Logger.log('cron_1min trigger set.');
  } finally {
    lock.releaseLock();
  }
}

function removeAllTriggers(){
  ScriptApp.getProjectTriggers().forEach(t => ScriptApp.deleteTrigger(t));
  Logger.log('all triggers removed.');
}
